package com.josecamporivas.moviesapispringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesApiSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
